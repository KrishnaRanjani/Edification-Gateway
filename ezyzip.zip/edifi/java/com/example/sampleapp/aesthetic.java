package com.example.sampleapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class aesthetic extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aesthetic);


        final Button aes1 ;
       aes1 = (Button)findViewById(R.id.aes1);
        aes1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1 =new Intent(getApplicationContext(),aes1.class);
                startActivity(int1);
            }
        });


        final Button aes2 ;
        aes2 = (Button)findViewById(R.id.aes2);
        aes2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2 =new Intent(getApplicationContext(),aes2.class);
                startActivity(int2);
            }
        });
        final Button aes3 ;
        aes3 = (Button)findViewById(R.id.aes3);
        aes3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int3 =new Intent(getApplicationContext(),aes3.class);
                startActivity(int3);
            }
        });
        final Button aes4 ;
        aes4 = (Button)findViewById(R.id.aes4);
        aes4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int4 =new Intent(getApplicationContext(),aes4.class);
                startActivity(int4);
            }
        });
        final Button aes5 ;
        aes5 = (Button)findViewById(R.id.aes5);
        aes5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int5 =new Intent(getApplicationContext(),aes5.class);
                startActivity(int5);
            }
        });
        final Button aes6 ;
        aes6= (Button)findViewById(R.id.aes6);
        aes6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int6 =new Intent(getApplicationContext(),aes6.class);
                startActivity(int6);
            }
        });
        final Button aes7 ;
        aes7 = (Button)findViewById(R.id.aes7);
        aes7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int7 =new Intent(getApplicationContext(),aes7.class);
                startActivity(int7);
            }
        });
        final Button aes8 ;
        aes8 = (Button)findViewById(R.id.aes8);
        aes8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int8 =new Intent(getApplicationContext(),aes8.class);
                startActivity(int8);
            }
        });
        final Button aes9 ;
        aes9 = (Button)findViewById(R.id.aes9);
        aes9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int9 =new Intent(getApplicationContext(),aes9.class);
                startActivity(int9);
            }
        });
        final Button aes10 ;
        aes10 = (Button)findViewById(R.id.aes10);
        aes10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int10 =new Intent(getApplicationContext(),aes10.class);
                startActivity(int10);
            }
        });
        final Button aes11 ;
        aes11 = (Button)findViewById(R.id.aes11);
        aes11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int11 =new Intent(getApplicationContext(),aes11.class);
                startActivity(int11);
            }
        });
        final Button aes12 ;
        aes12 = (Button)findViewById(R.id.aes12);
        aes12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int12 =new Intent(getApplicationContext(),aes12.class);
                startActivity(int12);
            }
        });
        final Button aes13 ;
        aes13 = (Button)findViewById(R.id.aes13);
        aes13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int13 =new Intent(getApplicationContext(),aes13.class);
                startActivity(int13);
            }
        });
        final Button aes14 ;
        aes14 = (Button)findViewById(R.id.aes14);
        aes14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int14=new Intent(getApplicationContext(),aes14.class);
                startActivity(int14);
            }
        });
        final Button aes15 ;
        aes15 = (Button)findViewById(R.id.aes15);
        aes15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int15 =new Intent(getApplicationContext(),aes15.class);
                startActivity(int15);
            }
        });
        final Button aes16 ;
        aes16 = (Button)findViewById(R.id.aes16);
        aes16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int16 =new Intent(getApplicationContext(),aes16.class);
                startActivity(int16);
            }
        });
        final Button aes17 ;
        aes17 = (Button)findViewById(R.id.aes17);
        aes17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int17 =new Intent(getApplicationContext(),aes17.class);
                startActivity(int17);
            }
        });
        final Button aes18 ;
        aes18 = (Button)findViewById(R.id.aes18);
        aes18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int18 =new Intent(getApplicationContext(),aes18.class);
                startActivity(int18);
            }
        });
        final Button aes19 ;
        aes19 = (Button)findViewById(R.id.aes19);
        aes19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int19 =new Intent(getApplicationContext(),aes19.class);
                startActivity(int19);
            }
        });
        final Button aes20 ;
        aes20 = (Button)findViewById(R.id.aes20);
        aes20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int20 =new Intent(getApplicationContext(),aes20.class);
                startActivity(int20);
            }
        });
        final Button aes21 ;
        aes21 = (Button)findViewById(R.id.aes21);
        aes21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int21 =new Intent(getApplicationContext(),aes21.class);
                startActivity(int21);
            }
        });
        final Button aes22 ;
        aes22 = (Button)findViewById(R.id.aes22);
        aes22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int22 =new Intent(getApplicationContext(),aes22.class);
                startActivity(int22);
            }
        });
        final Button aes23 ;
        aes23 = (Button)findViewById(R.id.aes23);
        aes23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int23 =new Intent(getApplicationContext(),aes23.class);
                startActivity(int23);
            }
        });
        final Button aes24 ;
        aes24 = (Button)findViewById(R.id.aes24);
        aes24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int24 =new Intent(getApplicationContext(),aes24.class);
                startActivity(int24);
            }
        });
        final Button aes25 ;
        aes25 = (Button)findViewById(R.id.aes25);
        aes25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int25 =new Intent(getApplicationContext(),aes25.class);
                startActivity(int25);
            }
        });
    }
}
