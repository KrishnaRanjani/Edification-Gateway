package com.example.sampleapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class artquallist extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artquallist);

        Button artdefence;
        artdefence= findViewById(R.id.art029);
        artdefence.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in1=new Intent(getApplicationContext(),defense_list.class);
                startActivity(in1);
            }
        });
        Button a1= findViewById(R.id.art001);
        a1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in1=new Intent(getApplicationContext(),arts1.class);
                startActivity(in1);
            }
        });
        Button a2= findViewById(R.id.art002);
        a2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in2=new Intent(getApplicationContext(),arts2.class);
                startActivity(in2);
            }
        });
        Button a3= findViewById(R.id.art003);
        a3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in3=new Intent(getApplicationContext(),arts3.class);
                startActivity(in3);
            }
        });
        Button a4= findViewById(R.id.art004);
        a4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in4=new Intent(getApplicationContext(),arts4.class);
                startActivity(in4);
            }
        });
        Button a5= findViewById(R.id.art005);
        a5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in5=new Intent(getApplicationContext(),arts5.class);
                startActivity(in5);
            }
        });
        Button a6= findViewById(R.id.art006);
        a6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in6=new Intent(getApplicationContext(),arts6.class);
                startActivity(in6);
            }
        });
        Button a7= findViewById(R.id.art007);
        a7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in7=new Intent(getApplicationContext(),arts7.class);
                startActivity(in7);
            }
        });
        Button a8= findViewById(R.id.art008);
        a8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in8=new Intent(getApplicationContext(),arts8.class);
                startActivity(in8);
            }
        });
        Button a9= findViewById(R.id.art009);
        a9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in9=new Intent(getApplicationContext(),arts9.class);
                startActivity(in9);
            }
        });
        Button a10= findViewById(R.id.art010);
        a10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in10=new Intent(getApplicationContext(),arts10.class);
                startActivity(in10);
            }
        });
        Button a11= findViewById(R.id.art011);
        a11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in11=new Intent(getApplicationContext(),arts11.class);
                startActivity(in11);
            }
        });
        Button a12= findViewById(R.id.art012);
        a12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in12=new Intent(getApplicationContext(),arts12.class);
                startActivity(in12);
            }
        });
        Button a13= findViewById(R.id.art013);
        a13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in13=new Intent(getApplicationContext(),arts13.class);
                startActivity(in13);
            }
        });
        Button a14= findViewById(R.id.art014);
        a14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in14=new Intent(getApplicationContext(),arts14.class);
                startActivity(in14);
            }
        });
        Button a15= findViewById(R.id.art015);
        a15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in15=new Intent(getApplicationContext(),arts15.class);
                startActivity(in15);
            }
        });
        Button a16= findViewById(R.id.art016);
        a16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in16=new Intent(getApplicationContext(),arts16.class);
                startActivity(in16);
            }
        });
        Button a17= findViewById(R.id.art017);
        a17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in17=new Intent(getApplicationContext(),arts17.class);
                startActivity(in17);
            }
        });
        Button a18= findViewById(R.id.art018);
        a18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in18=new Intent(getApplicationContext(),arts18.class);
                startActivity(in18);
            }
        });
        Button a19= findViewById(R.id.art019);
        a19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in19=new Intent(getApplicationContext(),arts19.class);
                startActivity(in19);
            }
        });
        Button a20= findViewById(R.id.art020);
        a20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in20=new Intent(getApplicationContext(),arts20.class);
                startActivity(in20);
            }
        });
        Button a21= findViewById(R.id.art021);
        a21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in21=new Intent(getApplicationContext(),arts21.class);
                startActivity(in21);
            }
        });
        Button a22= findViewById(R.id.art022);
        a22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in22=new Intent(getApplicationContext(),arts22.class);
                startActivity(in22);
            }
        });
        Button a23= findViewById(R.id.art023);
        a23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in23=new Intent(getApplicationContext(),arts23.class);
                startActivity(in23);
            }
        });
        Button a24= findViewById(R.id.art024);
        a24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in24=new Intent(getApplicationContext(),arts24.class);
                startActivity(in24);
            }
        });
    }
}


